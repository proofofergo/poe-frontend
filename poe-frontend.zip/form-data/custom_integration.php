<?php  
/**
 * $email = You will get value of email field
 * $firstname = You will get value of first name field
 *
 * Example : 
 * +++++++++++++
 * echo "<pre>Email : ".print_r($email,true)."</pre>";
 * echo "<pre>First name : ".print_r($firstname,true)."</pre>";
 */

?>